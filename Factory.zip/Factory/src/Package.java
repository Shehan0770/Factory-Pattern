import java.util.ArrayList;
import java.util.List;

public abstract class Package {

protected List<Facilities> facilities = new ArrayList<>();

public Package(){
    createPackage();
}
protected abstract void createPackage();

public String toString(){
    return "Package {"+"Included-"+ facilities +"}";
}


}
