public class WelcomeDrink extends Facilities {
@Override
public String toString() {

    return "WelcomeDrink";
}
}
