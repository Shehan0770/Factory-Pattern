public class SilverPackage extends Package{

@Override
protected void createPackage() {
    facilities.add(new WelcomeDrink());
    facilities.add(new Bar());

}
}
