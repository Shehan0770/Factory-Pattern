public class Bar extends Facilities {
@Override
public String toString() {

    return "Bar";
}
}
