public class BasicPackage extends Package{

@Override
protected void createPackage() {
    facilities.add(new WelcomeDrink());

}
}
