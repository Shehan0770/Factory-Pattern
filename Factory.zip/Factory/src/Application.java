public class Application {

public static void main(String[] args) {
    Package a1package = PackageFactory.CreatePackage(PackageCode.Basic);
    System.out.println(a1package);

    Package a2package = PackageFactory.CreatePackage(PackageCode.Silver);
    System.out.println(a2package);

    Package a3package = PackageFactory.CreatePackage(PackageCode.Gold);
    System.out.println(a3package);

    Package a4package = PackageFactory.CreatePackage(PackageCode.Premium);
    System.out.println(a4package);
}
}
