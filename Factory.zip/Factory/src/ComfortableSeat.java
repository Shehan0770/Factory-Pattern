public class ComfortableSeat extends Facilities {
@Override
public String toString() {

    return "ComfortableSeat";
}
}
