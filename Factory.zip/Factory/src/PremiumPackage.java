public class PremiumPackage extends Package {
@Override
protected void createPackage() {
    facilities.add(new WelcomeDrink());
    facilities.add(new Bar());
    facilities.add(new ComfortableSeat());
    facilities.add(new GoHomeTaxi());
}
}
