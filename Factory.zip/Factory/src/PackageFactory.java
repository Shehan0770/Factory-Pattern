public class PackageFactory {

public static Package CreatePackage(PackageCode PackageCode) {

    switch (PackageCode) {
        case Basic:
            return new BasicPackage();
        case Silver:
            return new SilverPackage();
        case Gold:
            return new GoldPackage();
        case Premium:
            return new PremiumPackage();
        default:
            return null;


    }
}


}
